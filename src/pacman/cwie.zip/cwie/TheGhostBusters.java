package pacman.cwie;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.Random;
import java.util.Set;

import pacman.controllers.Controller;
import pacman.game.Constants;
import pacman.game.Game;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;
import pacman.game.internal.Maze;
import pacman.game.internal.Node;
import pacman.neuralnetwork.*;

public class TheGhostBusters extends Controller<MOVE> 
{
    private boolean initialized = false;
    Random rand;
	
	public MOVE getMove(Game game,long timeDue)
	{		
		return new PeterVenkman().MakeDecision(game.copy(), timeDue);

	}
}